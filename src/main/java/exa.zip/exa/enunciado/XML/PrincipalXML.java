package exa.enunciado.XML;

import exa.enunciado.datos.Establo;

public class PrincipalXML {
	public Establo leerEstabloXMLdom(String nameFile) {
		return null;
	}

	public void saveEstabloXMLdoom(Establo e1, String nameFile) {
	}

}
